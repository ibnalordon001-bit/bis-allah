package com.focuslock.strict

/** مطابقة الكلمات المحظورة: تتجاهل الحالة والتشكيل وتوحّد الأشكال العربية المتشابهة. */
object Words {
    fun norm(s: CharSequence): String {
        val src = s.toString().lowercase()
        val sb = StringBuilder(src.length)
        for (ch in src) {
            if (ch in '\u064B'..'\u065F' || ch == '\u0670' || ch == '\u0640') continue   // تشكيل وتطويل
            if (ch in '\u200B'..'\u200F' || ch in '\u202A'..'\u202E' || ch == '\u2060' || ch == '\uFEFF') continue // محارف خفية
            sb.append(
                when (ch) {
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                    'ى' -> 'ي'
                    'ة' -> 'ه'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    private fun compact(s: String): String = s.filter { it.isLetterOrDigit() }

    class Matcher(words: Set<String>) {
        private val plain = words.map { norm(it).trim() }.filter { it.length >= 2 }.distinct()
        // لا نسمح بالمطابقة المتباعدة للكلمات القصيرة؛ فهي مصدر كبير للإيجابيات الكاذبة.
        private val spaced = plain.map { compact(it) }.filter { it.length >= 5 }.distinct()
        private val patterns = plain.mapNotNull { word ->
            val letters = word.count { it.isLetter() }
            val flexible = letters >= 4
            val arabic = word.any { it in '\u0600'..'\u06FF' }
            val prefix = if (flexible && arabic) "(?:[وف]?(?:لل|[بكل]?(?:ال)?))?" else ""
            val suffix = when {
                !flexible -> ""
                arabic -> "(?:ها|هم|هن|هما|كم|كن|كما|نا|ات|ان|ين|ون|ه|ك|ي)?"
                else -> "(?:s|es)?"
            }
            val body = word.split(Regex("\\s+")).joinToString("[^\\p{L}\\p{N}]+") { java.util.regex.Pattern.quote(it) }
            runCatching { Regex("(?<![\\p{L}\\p{N}])$prefix$body$suffix(?![\\p{L}\\p{N}])") }.getOrNull()
        }

        val isEmpty: Boolean get() = plain.isEmpty()

        fun matches(text: CharSequence?): Boolean {
            if (text.isNullOrEmpty() || plain.isEmpty()) return false
            val t = norm(text.take(20_000))
            if (patterns.any { it.containsMatchIn(t) }) return true
            if (spaced.isEmpty()) return false
            return spaced.any { hasSpacedMatch(t, it) }
        }

        // لا تكفي مطابقة substring بعد حذف الرموز؛ يجب أن تكون هناك فواصل
        // فعلية بين حروف الكلمة، مع حدود تمنع المطابقة داخل كلمة أطول.
        private fun hasSpacedMatch(text: String, word: String): Boolean {
            if (word.length < 5) return false
            for (start in text.indices) {
                if (text[start] != word[0]) continue
                if (start > 0 && text[start - 1].isLetterOrDigit()) continue
                var pos = start
                var separated = false
                var ok = true
                for (i in 1 until word.length) {
                    var next = pos + 1
                    while (next < text.length && !text[next].isLetterOrDigit()) {
                        separated = true
                        next++
                    }
                    if (next >= text.length || text[next] != word[i]) { ok = false; break }
                    pos = next
                }
                if (ok && separated && (pos + 1 == text.length || !text[pos + 1].isLetterOrDigit())) return true
            }
            return false
        }
    }
}
