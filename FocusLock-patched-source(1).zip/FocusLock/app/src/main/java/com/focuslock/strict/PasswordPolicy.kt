package com.focuslock.strict

enum class Issue { SHORT_PIN, SHORT_PASS, PIN_SIMPLE, WEAK_CLASSES, COMMON, REPEATS, SEQUENCE }

/** score من 0 إلى 4. ok = بلا مشاكل. */
data class Strength(val score: Int, val issue: Issue?) {
    val ok: Boolean get() = issue == null
}

object PasswordPolicy {
    private val common = setOf(
        "password", "passw0rd", "12345678", "123456789", "qwertyui", "qwertyuiop", "iloveyou",
        "admin123", "letmein1", "welcome1", "11111111", "abcd1234", "abc12345", "password1",
        "كلمةالسر", "مرحبا123"
    )

    fun isPin(s: String) = s.isNotEmpty() && s.all { it in '0'..'9' }

    fun evaluate(s: String): Strength =
        if (isPin(s)) evalPin(s) else evalPassword(s)

    private fun evalPin(s: String): Strength {
        if (s.length < 10) return Strength(0, Issue.SHORT_PIN)
        if (s.toSet().size < 4) return Strength(1, Issue.PIN_SIMPLE)
        if (hasRun(s, 4, sequence = true)) return Strength(1, Issue.SEQUENCE)
        if (hasRun(s, 3, sequence = false)) return Strength(1, Issue.REPEATS)
        for (p in 1..s.length / 2) {
            if (s.length % p == 0 && s == s.take(p).repeat(s.length / p)) return Strength(1, Issue.PIN_SIMPLE)
        }
        val score = 2 + (if (s.length >= 12) 1 else 0) + (if (s.length >= 16) 1 else 0)
        return Strength(score, null)
    }

    private fun evalPassword(s: String): Strength {
        if (s.length < 8) return Strength(0, Issue.SHORT_PASS)
        var classes = 0
        if (s.any { it.isLetter() && !it.isUpperCase() }) classes++
        if (s.any { it.isUpperCase() }) classes++
        if (s.any { it.isDigit() }) classes++
        if (s.any { !it.isLetterOrDigit() }) classes++
        if (classes < 3) return Strength(1, Issue.WEAK_CLASSES)
        val low = s.lowercase()
        if (common.any { low == it || low.contains("password") || low.contains("12345") }) {
            return Strength(1, Issue.COMMON)
        }
        if (hasRun(s, 3, sequence = false)) return Strength(1, Issue.REPEATS)
        if (hasRun(low, 4, sequence = true)) return Strength(1, Issue.SEQUENCE)
        val score = (classes - 1) + (if (s.length >= 12) 1 else 0) + (if (s.length >= 16) 1 else 0)
        return Strength(score.coerceIn(2, 4), null)
    }

    /** sequence=true: تسلسل متزايد/متناقص بطول n. sequence=false: نفس المحرف n مرات. */
    private fun hasRun(s: String, n: Int, sequence: Boolean): Boolean {
        var up = 1; var down = 1; var same = 1
        for (i in 1 until s.length) {
            val d = s[i].code - s[i - 1].code
            up = if (d == 1) up + 1 else 1
            down = if (d == -1) down + 1 else 1
            same = if (d == 0) same + 1 else 1
            if (sequence && (up >= n || down >= n)) return true
            if (!sequence && same >= n) return true
        }
        return false
    }
}
