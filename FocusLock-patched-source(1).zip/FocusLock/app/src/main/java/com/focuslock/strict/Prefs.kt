package com.focuslock.strict

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("focuslock", Context.MODE_PRIVATE)

    var passHash: String?
        get() = sp.getString("hash", null)
        set(v) { sp.edit().putString("hash", v).apply() }
    var passSalt: String?
        get() = sp.getString("salt", null)
        set(v) { sp.edit().putString("salt", v).apply() }
    var strictEndAt: Long
        get() = sp.getLong("strictEnd", 0L)
        set(v) { sp.edit().putLong("strictEnd", v).apply() }
    var strictStartAt: Long
        get() = sp.getLong("strictStart", 0L)
        set(v) { sp.edit().putLong("strictStart", v).apply() }
    /** آخر حالة طبّقناها لقيد خيارات المطور (true = محظورة). */
    var devBlocked: Boolean
        get() = sp.getBoolean("devBlocked", false)
        set(v) { sp.edit().putBoolean("devBlocked", v).apply() }
    var exitRequestedAt: Long
        get() = sp.getLong("exitAt", 0L)
        set(v) { sp.edit().putLong("exitAt", v).apply() }
    var recHash: String?
        get() = sp.getString("recHash", null)
        set(v) { sp.edit().putString("recHash", v).apply() }
    var recSalt: String?
        get() = sp.getString("recSalt", null)
        set(v) { sp.edit().putString("recSalt", v).apply() }
    var recFails: Int
        get() = sp.getInt("recFails", 0)
        set(v) { sp.edit().putInt("recFails", v).apply() }
    var recLockUntil: Long
        get() = sp.getLong("recLock", 0L)
        set(v) { sp.edit().putLong("recLock", v).apply() }
    var graceUntil: Long
        get() = sp.getLong("grace", 0L)
        set(v) { sp.edit().putLong("grace", v).apply() }
    var lockUntil: Long
        get() = sp.getLong("lockUntil", 0L)
        set(v) { sp.edit().putLong("lockUntil", v).apply() }
    var failCount: Int
        get() = sp.getInt("fails", 0)
        set(v) { sp.edit().putInt("fails", v).apply() }

    var blockedApps: Set<String>
        get() = getSet("blockedApps")
        set(v) = putSet("blockedApps", v)
    var lockedApps: Set<String>
        get() = getSet("lockedApps")
        set(v) = putSet("lockedApps", v)
    var blockedSites: Set<String>
        get() = getSet("blockedSites")
        set(v) = putSet("blockedSites", v)
    var blockedWords: Set<String>
        get() = getSet("blockedWords")
        set(v) = putSet("blockedWords", v)

    val hasPassword: Boolean get() = passHash != null
    val hasRecovery: Boolean get() = recHash != null
    fun isStrict(): Boolean = strictEndAt > System.currentTimeMillis()

    private fun getSet(k: String): Set<String> = sp.getStringSet(k, emptySet())?.toSet() ?: emptySet()
    private fun putSet(k: String, v: Set<String>) { sp.edit().putStringSet(k, HashSet(v)).apply() }
}
