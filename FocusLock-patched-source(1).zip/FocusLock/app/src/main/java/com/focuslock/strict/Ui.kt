package com.focuslock.strict

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF6FD6BE)) else lightColorScheme(primary = Color(0xFF0F6B57))
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
        }
    }
}

@Composable
fun durationText(ms: Long): String {
    val ud = stringResource(R.string.unit_d)
    val uh = stringResource(R.string.unit_h)
    val um = stringResource(R.string.unit_m)
    val us = stringResource(R.string.unit_s)
    val t = ms.coerceAtLeast(0)
    val d = t / T.DAY
    val h = (t % T.DAY) / T.HOUR
    val m = (t % T.HOUR) / T.MIN
    val s = (t % T.MIN) / 1000
    return when {
        d > 0 -> "$d $ud  $h $uh  $m $um"
        h > 0 -> "$h $uh  $m $um"
        else -> "$m $um  $s $us"
    }
}

@Composable
fun PasswordField(value: String, onChange: (String) -> Unit, label: String) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            TextButton(onClick = { show = !show }) {
                Text(stringResource(if (show) R.string.hide else R.string.show))
            }
        }
    )
}

private fun issueRes(i: Issue): Int = when (i) {
    Issue.SHORT_PIN -> R.string.issue_short_pin
    Issue.SHORT_PASS -> R.string.issue_short_pass
    Issue.PIN_SIMPLE -> R.string.issue_pin_simple
    Issue.WEAK_CLASSES -> R.string.issue_weak_classes
    Issue.COMMON -> R.string.issue_common
    Issue.REPEATS -> R.string.issue_repeats
    Issue.SEQUENCE -> R.string.issue_sequence
}

@Composable
fun StrengthMeter(secret: String) {
    if (secret.isEmpty()) return
    val s = PasswordPolicy.evaluate(secret)
    val labels = listOf(R.string.str_0, R.string.str_1, R.string.str_2, R.string.str_3, R.string.str_4)
    val colors = listOf(Color(0xFFD32F2F), Color(0xFFD32F2F), Color(0xFFF9A825), Color(0xFF388E3C), Color(0xFF1B5E20))
    val score = s.score.coerceIn(0, 4)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        LinearProgressIndicator(
            progress = { (score + 1) / 5f },
            color = colors[score],
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )
        Text(stringResource(labels[score]), color = colors[score], style = MaterialTheme.typography.bodySmall)
        s.issue?.let { Text(stringResource(issueRes(it)), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun PasswordCreator(askCurrent: Boolean, buttonLabel: String, onDone: (String) -> Unit) {
    val ctx = LocalContext.current
    var cur by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val st = PasswordPolicy.evaluate(a)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.password_rules), style = MaterialTheme.typography.bodyMedium)
        if (askCurrent) PasswordField(cur, { cur = it }, stringResource(R.string.current_password))
        PasswordField(a, { a = it }, stringResource(R.string.new_password))
        StrengthMeter(a)
        PasswordField(b, { b = it }, stringResource(R.string.confirm_password))
        if (b.isNotEmpty() && a != b) {
            Text(stringResource(R.string.mismatch), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            enabled = st.ok && a == b && (!askCurrent || cur.isNotEmpty()),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (askCurrent) {
                    val r = Auth.verify(Prefs(ctx), cur)
                    if (!r.ok) {
                        err = if (r.waitSec > 0) ctx.getString(R.string.try_later, r.waitSec) else ctx.getString(R.string.wrong_password)
                        return@Button
                    }
                }
                onDone(a)
            }
        ) { Text(buttonLabel) }
    }
}

@Composable
fun PasswordGate(
    title: String,
    subtitle: String?,
    onSuccess: () -> Unit,
    onCancel: (() -> Unit)? = null,
    extra: @Composable ColumnScope.() -> Unit = {}
) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    fun submit() {
        val r = Auth.verify(Prefs(ctx), input)
        if (r.ok) onSuccess() else {
            input = ""
            error = if (r.waitSec > 0) ctx.getString(R.string.try_later, r.waitSec) else ctx.getString(R.string.wrong_password)
        }
    }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        if (subtitle != null) Text(subtitle, textAlign = TextAlign.Center)
        PasswordField(input, { input = it; error = null }, stringResource(R.string.enter_password))
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = { submit() }, enabled = input.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.enter_button))
        }
        if (onCancel != null) TextButton(onClick = onCancel) { Text(stringResource(R.string.go_home)) }
        extra()
    }
}

@Composable
fun ConfirmPasswordDialog(title: String, text: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    val ctx = LocalContext.current
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text)
                PasswordField(pw, { pw = it; err = null }, stringResource(R.string.enter_password))
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val r = Auth.verify(Prefs(ctx), pw)
                if (r.ok) onOk() else err = if (r.waitSec > 0) ctx.getString(R.string.try_later, r.waitSec) else ctx.getString(R.string.wrong_password)
            }) { Text(stringResource(R.string.confirm)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun BlockScreen(isSite: Boolean, target: String, onHome: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    val remaining = prefs.strictEndAt - now
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(if (isSite) R.string.blocked_site else R.string.blocked_app), style = MaterialTheme.typography.headlineMedium)
        Text(target, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Text(stringResource(R.string.block_message), textAlign = TextAlign.Center)
        if (remaining > 0) {
            Text(stringResource(R.string.time_left), style = MaterialTheme.typography.bodySmall)
            Text(durationText(remaining), style = MaterialTheme.typography.headlineSmall)
        }
        Button(onClick = onHome) { Text(stringResource(R.string.go_home)) }
    }
}
