package com.focuslock.strict

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

const val CMD_OWNER = "adb shell dpm set-device-owner com.focuslock.strict/.AdminReceiver"
const val CMD_GRANT = "adb shell pm grant com.focuslock.strict android.permission.WRITE_SECURE_SETTINGS"

object Session {
    var unlocked by mutableStateOf(false)
    var leftAt = 0L
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Strict.checkExpiry(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { AppTheme { Root() } }
    }

    override fun onStart() {
        super.onStart()
        val grace = if (Prefs(this).isStrict()) 0L else 60_000L
        if (SystemClock.elapsedRealtime() - Session.leftAt > grace) Session.unlocked = false
    }

    override fun onStop() {
        super.onStop()
        Session.leftAt = SystemClock.elapsedRealtime()
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var hasPass by remember { mutableStateOf(prefs.hasPassword) }
    var resetting by remember { mutableStateOf(false) }          // تم التحقق من كود الاستعادة
    var needRecovery by remember { mutableStateOf(!prefs.hasRecovery) }
    when {
        !hasPass -> SetupScreen { hasPass = true; needRecovery = true; Session.unlocked = true }
        resetting -> ResetPasswordScreen(
            onDone = { resetting = false; needRecovery = true; Session.unlocked = true },
            onCancel = { resetting = false }
        )
        !Session.unlocked -> PasswordGate(
            title = stringResource(R.string.enter_password),
            subtitle = null,
            onSuccess = { Session.unlocked = true },
            extra = { ForgotSection { resetting = true } }
        )
        needRecovery -> RecoveryCodeScreen(onCancel = null) { needRecovery = false }
        else -> Dashboard()
    }
}

@Composable
fun SetupScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(32.dp))
        Text(stringResource(R.string.setup_title), style = MaterialTheme.typography.headlineMedium)
        Text(stringResource(R.string.setup_intro))
        PasswordCreator(false, stringResource(R.string.setup_save)) {
            Auth.setPassword(Prefs(ctx), it)
            onDone()
        }
    }
}

/** "نسيت كلمة السر": الطريقة الوحيدة هي كود الاستعادة. لا يوجد انتظار ولا بديل. */
@Composable
fun ForgotSection(onVerified: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var open by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    TextButton(onClick = { open = !open }) { Text(stringResource(R.string.forgot)) }
    if (open) {
        Text(stringResource(R.string.forgot_desc), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        CodeField(code, { code = it; err = null }, stringResource(R.string.forgot_code_label))
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            enabled = code.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val r = Auth.verifyRecovery(prefs, code)
                code = ""
                if (r.ok) onVerified()
                else err = if (r.waitSec > 0) ctx.getString(R.string.try_later, r.waitSec) else ctx.getString(R.string.bad_code)
            }
        ) { Text(stringResource(R.string.forgot_reset)) }
    }
}

@Composable
fun CodeField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(30)) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, textDirection = TextDirection.Ltr),
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, keyboardType = KeyboardType.Password)
    )
}

/** بعد التحقق من كود الاستعادة: تعيين كلمة سر جديدة. لا تتغير كلمة السر القديمة إلا عند الحفظ. */
@Composable
fun ResetPasswordScreen(onDone: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(32.dp))
        Text(stringResource(R.string.reset_title), style = MaterialTheme.typography.headlineMedium)
        Text(stringResource(R.string.reset_intro))
        PasswordCreator(false, stringResource(R.string.setup_save)) {
            Auth.setPassword(Prefs(ctx), it)
            onDone()
        }
        TextButton(onClick = onCancel) { Text(stringResource(R.string.cancel)) }
    }
}

/**
 * يعرض كود الاستعادة مرة واحدة. لا يُحفظ (كـ hash) إلا بعد أن يكتبه المستخدم مرة ثانية للتأكيد،
 * وإلا لضاع كود لم يره أحد.
 */
@Composable
fun RecoveryCodeScreen(onCancel: (() -> Unit)?, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val code = remember { Auth.generateRecoveryCode() }
    var typed by remember { mutableStateOf("") }
    val matches = Auth.normalizeCode(typed) == Auth.normalizeCode(code)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (onCancel != null) TextButton(onClick = onCancel) { Text(stringResource(R.string.back)) } else Spacer(Modifier.height(32.dp))
        Text(stringResource(R.string.recovery_title), style = MaterialTheme.typography.headlineMedium)
        Text(stringResource(R.string.recovery_intro))
        SelectionContainer {
            Text(
                code,
                Modifier.fillMaxWidth(),
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontFamily = FontFamily.Monospace, textDirection = TextDirection.Ltr, textAlign = TextAlign.Center
                ),
                color = MaterialTheme.colorScheme.primary
            )
        }
        Text(stringResource(R.string.recovery_warning), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        CodeField(typed, { typed = it }, stringResource(R.string.recovery_confirm_label))
        if (Auth.normalizeCode(typed).length >= 16 && !matches) {
            Text(stringResource(R.string.recovery_mismatch), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Button(
            enabled = matches,
            modifier = Modifier.fillMaxWidth(),
            onClick = { Auth.setRecoveryCode(Prefs(ctx), code); onDone() }
        ) { Text(stringResource(R.string.recovery_save)) }
    }
}

sealed interface Screen {
    data object Home : Screen
    data class Apps(val lock: Boolean) : Screen
    data object Sites : Screen
    data object WordList : Screen
    data object ChangePass : Screen
    data object NewRecovery : Screen
}

@Composable
fun Dashboard() {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
    when (val s = screen) {
        Screen.Home -> HomeScreen { screen = it }
        is Screen.Apps -> AppsScreen(s.lock) { screen = Screen.Home }
        Screen.Sites -> SitesScreen { screen = Screen.Home }
        Screen.WordList -> WordsScreen { screen = Screen.Home }
        Screen.ChangePass -> ChangePassScreen { screen = Screen.Home }
        Screen.NewRecovery -> RecoveryCodeScreen(onCancel = { screen = Screen.Home }) { screen = Screen.Home }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun StatusRow(label: String, ok: Boolean, onEnable: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(label)
            Text(
                stringResource(if (ok) R.string.on_mark else R.string.off_mark),
                color = if (ok) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
        if (!ok && onEnable != null) Button(onClick = onEnable) { Text(stringResource(R.string.enable)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val policy = remember { Policy(ctx) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { delay(1000); Strict.checkExpiry(ctx); now = System.currentTimeMillis() }
    }

    // نقرأ كل القيم المتغيرة هنا ليُعاد رسم الشاشة كل ثانية
    val strict = prefs.strictEndAt > now
    val remaining = prefs.strictEndAt - now
    val exitAt = prefs.exitRequestedAt
    val isOwner = policy.isOwner()
    val a11y = A11y.isEnabled(ctx)
    val nApps = prefs.blockedApps.size
    val nSites = prefs.blockedSites.size
    val nWords = prefs.blockedWords.size
    val nLocked = prefs.lockedApps.size

    var d by remember { mutableStateOf("") }
    var h by remember { mutableStateOf("") }
    var m by remember { mutableStateOf("30") }
    var confirmStart by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var confirmOwner by remember { mutableStateOf(false) }
    var confirmNewCode by remember { mutableStateOf(false) }

    val total = (d.toLongOrNull() ?: 0) * T.DAY + (h.toLongOrNull() ?: 0) * T.HOUR + (m.toLongOrNull() ?: 0) * T.MIN
    val validTotal = total in Strict.MIN_MS..Strict.MAX_MS
    fun preset(ms: Long) {
        d = (ms / T.DAY).toString(); h = ((ms % T.DAY) / T.HOUR).toString(); m = ((ms % T.HOUR) / T.MIN).toString()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(R.string.dash_title), style = MaterialTheme.typography.headlineMedium)

        SectionCard(stringResource(R.string.status_title)) {
            StatusRow(stringResource(R.string.st_owner), isOwner, null)
            StatusRow(stringResource(R.string.st_a11y), a11y) {
                if (!A11y.tryEnable(ctx)) ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) {
                Text(stringResource(R.string.st_battery))
            }
            if (!isOwner || !a11y) {
                Text(stringResource(R.string.owner_help), style = MaterialTheme.typography.bodySmall)
                SelectionContainer {
                    Text(
                        CMD_OWNER + "\n\n" + CMD_GRANT,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace, textDirection = TextDirection.Ltr, textAlign = TextAlign.Left
                        )
                    )
                }
            }
        }

        SectionCard(stringResource(R.string.strict_title)) {
            if (strict) {
                Text(stringResource(R.string.strict_active), color = MaterialTheme.colorScheme.primary)
                Text(stringResource(R.string.time_left), style = MaterialTheme.typography.bodySmall)
                Text(durationText(remaining), style = MaterialTheme.typography.headlineSmall)
                if (Strict.devGraceActive(prefs)) {
                    val graceLeft = prefs.strictStartAt + Strict.DEV_GRACE_MS - now
                    Text(stringResource(R.string.dev_grace, durationText(graceLeft)), style = MaterialTheme.typography.bodySmall)
                }
                HorizontalDivider()
                Text(stringResource(R.string.emergency_title), style = MaterialTheme.typography.titleSmall)
                Text(stringResource(R.string.emergency_desc), style = MaterialTheme.typography.bodySmall)
                if (exitAt == 0L) {
                    OutlinedButton(onClick = { prefs.exitRequestedAt = System.currentTimeMillis() }) {
                        Text(stringResource(R.string.request_exit))
                    }
                } else {
                    val left = exitAt + Strict.EXIT_WAIT_MS - now
                    if (left > 0) {
                        Text(stringResource(R.string.exit_pending, durationText(left)))
                        TextButton(onClick = { prefs.exitRequestedAt = 0 }) { Text(stringResource(R.string.cancel_exit)) }
                    } else {
                        Button(onClick = { confirmExit = true }) { Text(stringResource(R.string.exit_now)) }
                    }
                }
            } else {
                Text(stringResource(R.string.duration_label))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        R.string.p_3m to 3 * T.MIN, R.string.p_30m to 30 * T.MIN, R.string.p_1h to T.HOUR, R.string.p_1d to T.DAY,
                        R.string.p_1w to 7 * T.DAY, R.string.p_1mo to 30 * T.DAY,
                        R.string.p_3mo to 90 * T.DAY, R.string.p_6mo to 180 * T.DAY
                    ).forEach { (label, ms) ->
                        AssistChip(onClick = { preset(ms) }, label = { Text(stringResource(label)) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(d, { d = it.filter(Char::isDigit).take(3) }, Modifier.weight(1f), singleLine = true,
                        label = { Text(stringResource(R.string.days)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(h, { h = it.filter(Char::isDigit).take(4) }, Modifier.weight(1f), singleLine = true,
                        label = { Text(stringResource(R.string.hours)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(m, { m = it.filter(Char::isDigit).take(6) }, Modifier.weight(1f), singleLine = true,
                        label = { Text(stringResource(R.string.minutes)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Text(stringResource(R.string.duration_range), style = MaterialTheme.typography.bodySmall)
                if (total > 0) Text(stringResource(R.string.duration_total, durationText(total)))
                if (!a11y) Text(stringResource(R.string.need_a11y), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(enabled = validTotal && a11y, onClick = { confirmStart = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.start_strict))
                }
            }
        }

        SectionCard(stringResource(R.string.lists_title)) {
            OutlinedButton(onClick = { go(Screen.Apps(false)) }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.blocked_apps_row, nApps)) }
            OutlinedButton(onClick = { go(Screen.Sites) }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.blocked_sites_row, nSites)) }
            OutlinedButton(onClick = { go(Screen.WordList) }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.blocked_words_row, nWords)) }
            OutlinedButton(onClick = { go(Screen.Apps(true)) }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.locked_apps_row, nLocked)) }
        }

        OutlinedButton(onClick = { go(Screen.ChangePass) }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.change_password)) }
        OutlinedButton(onClick = { confirmNewCode = true }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.new_recovery)) }
        if (isOwner && !strict) {
            TextButton(onClick = { confirmOwner = true }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.remove_owner)) }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmStart) {
        AlertDialog(
            onDismissRequest = { confirmStart = false },
            title = { Text(stringResource(R.string.start_confirm_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.start_confirm_body, durationText(total)))
                    if (!isOwner) Text(stringResource(R.string.no_owner_warning), color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = { Strict.start(ctx, total); confirmStart = false }) { Text(stringResource(R.string.confirm)) }
            },
            dismissButton = { TextButton(onClick = { confirmStart = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (confirmExit) {
        ConfirmPasswordDialog(
            stringResource(R.string.exit_confirm_title), stringResource(R.string.exit_confirm_body),
            onDismiss = { confirmExit = false }, onOk = { Strict.end(ctx); confirmExit = false }
        )
    }
    if (confirmNewCode) {
        ConfirmPasswordDialog(
            stringResource(R.string.new_recovery), stringResource(R.string.new_recovery_body),
            onDismiss = { confirmNewCode = false }, onOk = { confirmNewCode = false; go(Screen.NewRecovery) }
        )
    }
    if (confirmOwner) {
        ConfirmPasswordDialog(
            stringResource(R.string.remove_owner), stringResource(R.string.remove_owner_body),
            onDismiss = { confirmOwner = false }, onOk = { policy.relinquishOwner(); confirmOwner = false }
        )
    }
}

@Composable
fun ChangePassScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
        Text(stringResource(R.string.change_password), style = MaterialTheme.typography.headlineSmall)
        PasswordCreator(true, stringResource(R.string.setup_save)) {
            Auth.setPassword(Prefs(ctx), it)
            onBack()
        }
    }
}

private data class AppItem(val label: String, val pkg: String)

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val protected = Guard.protectedPackages(ctx) + Guard.SETTINGS
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName !in protected }
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun AppsScreen(lock: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val strict = prefs.isStrict()
    var selected by remember { mutableStateOf(if (lock) prefs.lockedApps else prefs.blockedApps) }
    var query by remember { mutableStateOf("") }
    val apps by produceState<List<AppItem>?>(null) { value = withContext(Dispatchers.IO) { loadApps(ctx) } }

    fun toggle(pkg: String) {
        val next = if (pkg in selected) selected - pkg else selected + pkg
        selected = next
        if (lock) prefs.lockedApps = next else prefs.blockedApps = next
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(
                stringResource(if (lock) R.string.locked_apps_title else R.string.blocked_apps_title),
                style = MaterialTheme.typography.titleLarge
            )
        }
        if (strict) Text(stringResource(R.string.strict_no_remove), style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.search)) })
        val list = apps
        if (list == null) {
            CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        } else {
            val shown = list.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown, key = { it.pkg }) { app ->
                    val checked = app.pkg in selected
                    val canToggle = !(strict && checked)
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = canToggle) { toggle(app.pkg) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = checked, onCheckedChange = null, enabled = canToggle)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(app.label)
                            Text(app.pkg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SitesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val strict = prefs.isStrict()
    var sites by remember { mutableStateOf(prefs.blockedSites) }
    var input by remember { mutableStateOf("") }
    var invalid by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(stringResource(R.string.sites_title), style = MaterialTheme.typography.titleLarge)
        }
        if (strict) Text(stringResource(R.string.strict_no_remove), style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it; invalid = false }, Modifier.weight(1f), singleLine = true,
                label = { Text(stringResource(R.string.site_hint)) }, isError = invalid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
            )
            Button(onClick = {
                val dom = Guard.normalizeDomain(input)
                if (dom == null) invalid = true else {
                    sites = sites + dom
                    prefs.blockedSites = sites
                    input = ""
                }
            }) { Text(stringResource(R.string.add)) }
        }
        if (invalid) Text(stringResource(R.string.invalid_domain), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        if (sites.isEmpty()) Text(stringResource(R.string.no_items))
        LazyColumn(Modifier.fillMaxSize()) {
            items(sites.sorted(), key = { it }) { site ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(site, Modifier.weight(1f))
                    TextButton(enabled = !strict, onClick = {
                        sites = sites - site
                        prefs.blockedSites = sites
                    }) { Text(stringResource(R.string.remove)) }
                }
            }
        }
    }
}

@Composable
fun WordsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val strict = prefs.isStrict()
    var words by remember { mutableStateOf(prefs.blockedWords) }
    var input by remember { mutableStateOf("") }
    var invalid by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(stringResource(R.string.words_title), style = MaterialTheme.typography.titleLarge)
        }
        Text(stringResource(R.string.words_note), style = MaterialTheme.typography.bodySmall)
        if (strict) Text(stringResource(R.string.strict_no_remove), style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it.take(40); invalid = false }, Modifier.weight(1f), singleLine = true,
                label = { Text(stringResource(R.string.word_hint)) }, isError = invalid
            )
            Button(onClick = {
                val w = input.trim().lowercase()
                if (Words.norm(w).trim().length < 2) invalid = true else {
                    words = words + w
                    prefs.blockedWords = words
                    input = ""
                }
            }) { Text(stringResource(R.string.add)) }
        }
        if (invalid) Text(stringResource(R.string.invalid_word), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        if (words.isEmpty()) Text(stringResource(R.string.no_items))
        LazyColumn(Modifier.fillMaxSize()) {
            items(words.sorted(), key = { it }) { word ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(word, Modifier.weight(1f))
                    TextButton(enabled = !strict, onClick = {
                        words = words - word
                        prefs.blockedWords = words
                    }) { Text(stringResource(R.string.remove)) }
                }
            }
        }
    }
}
