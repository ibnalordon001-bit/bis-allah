package com.focuslock.strict

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        context.getString(R.string.admin_disable_warning)
}

/** كل ما يخص صلاحيات مالك الجهاز (Device Owner). */
class Policy(context: Context) {
    private val ctx = context.applicationContext
    private val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(ctx, AdminReceiver::class.java)

    fun isOwner(): Boolean = dpm.isDeviceOwnerApp(ctx.packageName)

    private fun restrictions(): List<String> = buildList {
        add(UserManager.DISALLOW_UNINSTALL_APPS)      // منع إلغاء تثبيت أي تطبيق
        add(UserManager.DISALLOW_APPS_CONTROL)        // منع إيقاف/تعطيل/مسح بيانات التطبيقات
        add(UserManager.DISALLOW_SAFE_BOOT)           // منع Safe Mode
        add(UserManager.DISALLOW_FACTORY_RESET)       // منع مسح الجهاز من الإعدادات
        add(UserManager.DISALLOW_ADD_USER)            // منع إنشاء مستخدم جديد
        if (Build.VERSION.SDK_INT >= 28) add(UserManager.DISALLOW_CONFIG_DATE_TIME) // منع التلاعب بالساعة
    }

    /** خيارات المطور: مفتوحة خلال أول 72 ساعة من الوضع الصارم، ثم محظورة. */
    fun setDevOptionsBlocked(block: Boolean) {
        if (!isOwner()) return
        if (block) dpm.addUserRestriction(admin, UserManager.DISALLOW_DEBUGGING_FEATURES)
        else dpm.clearUserRestriction(admin, UserManager.DISALLOW_DEBUGGING_FEATURES)
    }

    fun applyStrict() {
        if (!isOwner()) return
        restrictions().forEach { dpm.addUserRestriction(admin, it) }
        setDevOptionsBlocked(!Strict.devGraceActive(Prefs(ctx)))
        dpm.setUninstallBlocked(admin, ctx.packageName, true)
        if (Build.VERSION.SDK_INT >= 30) dpm.setAutoTimeEnabled(admin, true)
    }

    fun releaseStrict() {
        if (!isOwner()) return
        restrictions().forEach { dpm.clearUserRestriction(admin, it) }
        dpm.clearUserRestriction(admin, UserManager.DISALLOW_DEBUGGING_FEATURES)
        dpm.setUninstallBlocked(admin, ctx.packageName, false)
    }

    @Suppress("DEPRECATION")
    fun relinquishOwner() {
        if (isOwner()) {
            releaseStrict()
            dpm.clearDeviceOwnerApp(ctx.packageName)
        }
    }
}
