package com.focuslock.strict

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

object T {
    const val MIN = 60_000L
    const val HOUR = 60 * MIN
    const val DAY = 24 * HOUR
}

object Strict {
    const val MIN_MS = 3 * T.MIN
    const val MAX_MS = 183 * T.DAY
    const val EXIT_WAIT_MS = 24 * T.HOUR
    const val DEV_GRACE_MS = 72 * T.HOUR   // خيارات المطور تبقى مفتوحة خلال أول 72 ساعة

    /** هل ما زالت مهلة الـ72 ساعة قائمة؟ (جلسة بدأت بنسخة قديمة بلا وقت بدء = لا مهلة). */
    fun devGraceActive(p: Prefs): Boolean =
        p.isStrict() && p.strictStartAt > 0 && System.currentTimeMillis() < p.strictStartAt + DEV_GRACE_MS

    /** يطبّق قيد خيارات المطور حسب المهلة. يُستدعى دورياً وعند الإقلاع وعند انتهاء المهلة. */
    fun syncDevOptions(ctx: Context) {
        val p = Prefs(ctx)
        if (!p.isStrict()) return
        val block = !devGraceActive(p)
        if (block != p.devBlocked) {
            Policy(ctx).setDevOptionsBlocked(block)
            p.devBlocked = block
        }
    }

    fun start(ctx: Context, durationMs: Long): Boolean {
        val c = ctx.applicationContext
        val p = Prefs(c)
        if (!p.hasPassword || p.isStrict() || durationMs !in MIN_MS..MAX_MS) return false
        val end = System.currentTimeMillis() + durationMs
        p.strictEndAt = end
        p.strictStartAt = System.currentTimeMillis()
        p.exitRequestedAt = 0
        p.devBlocked = false
        Policy(c).applyStrict()
        scheduleGrace(c, p.strictStartAt + DEV_GRACE_MS)
        A11y.tryEnable(c)
        schedule(c, end)
        GuardService.start(c)
        return true
    }

    fun end(ctx: Context) {
        val c = ctx.applicationContext
        val p = Prefs(c)
        p.strictEndAt = 0
        p.strictStartAt = 0
        p.exitRequestedAt = 0
        p.devBlocked = false
        Policy(c).releaseStrict()
        c.getSystemService(AlarmManager::class.java).cancel(pending(c))
        c.getSystemService(AlarmManager::class.java).cancel(pending(c, 2))
        c.stopService(Intent(c, GuardService::class.java))
    }

    fun checkExpiry(ctx: Context) {
        val p = Prefs(ctx)
        if (p.strictEndAt > 0 && !p.isStrict()) end(ctx)
    }

    fun schedule(ctx: Context, at: Long) {
        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
    }

    fun scheduleGrace(ctx: Context, at: Long) {
        if (at <= System.currentTimeMillis()) return
        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx, 2))
    }

    private fun pending(ctx: Context, code: Int = 1): PendingIntent = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, ExpiryReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

class ExpiryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Strict.checkExpiry(context)
        Strict.syncDevOptions(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = Prefs(context)
        Strict.checkExpiry(context)
        if (p.isStrict()) {
            Strict.schedule(context, p.strictEndAt)
            if (p.strictStartAt > 0) Strict.scheduleGrace(context, p.strictStartAt + Strict.DEV_GRACE_MS)
            Strict.syncDevOptions(context)
            GuardService.start(context)
        }
    }
}
